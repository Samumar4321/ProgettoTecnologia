/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package presetreaderandwriter;

import java.awt.*;
import javax.swing.*;

/**
 *
 * @author samum
 */
public class myComponent extends JComponent{
       @Override
       public void paint(Graphics g) {
          g.setColor(Color.red);
         g.drawRect(20,10,100,60);
       }
}
